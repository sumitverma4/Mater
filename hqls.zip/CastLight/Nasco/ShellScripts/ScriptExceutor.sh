#!/bin/bash
if [ -z "$1" ]
  then
    echo "Provide Configuration file as parameter"
    echo "e.g. -> sh ScriptExceutor.sh Script.cfg"
    exit 1
fi
DB_NAME=`grep DB_NAME  $1 | cut -d ":" -f2`
NASCO_HQL_FILENAME=`grep NASCO_HQL_FILENAME  $1 | cut -d ":" -f2`
NASCO_HQL_LOCATION=`grep NASCO_HQL_LOCATION  $1 | cut -d ":" -f2`
SCRIPT_LOCATION=`grep SCRIPT_LOCATION  $1 | cut -d ":" -f2`
SCRIPT_NAME=`grep SCRIPT_NAME  $1 | cut -d ":" -f2`
CONFIG_FILENAME=`grep CONFIG_FILENAME  $1 | cut -d ":" -f2`

beeline -u 'jdbc:hive2://dwbdprod1r1m.wellpoint.com:2181,dwbdprod1r2m.wellpoint.com:2181,dwbdprod1r3m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${NASCO_HQL_LOCATION}/${NASCO_HQL_FILENAME}"

sh $SCRIPT_LOCATION/Castlight_Elite_extract.sh $SCRIPT_LOCATION/Castlight_Elite_Extract.cfg
sh $SCRIPT_LOCATION/Castlight_R1-R4_Nasco_extract.sh $SCRIPT_LOCATION/Castlight_R1-R4_Nasco_extract.cfg
#sh $SCRIPT_LOCATION/Castlight_Nasco_extract.sh $SCRIPT_LOCATION/Castlight_Nasco_extract.cfg
