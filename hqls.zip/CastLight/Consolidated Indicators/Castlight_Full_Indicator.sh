#!/bin/bash
QUERY=`grep QUERY  $1 | cut -d ":" -f2`
WORKING_DIRECTORY=`grep WORKING_DIRECTORY  $1 | cut -d ":" -f2`
HADOOP_PATH=`grep HADOOP_PATH  $1 | cut -d ":" -f2`
file=Nasco.txt
ARC_DIR=`grep ARC_DIR $1 | awk -F":" '{print $2}'`
cd $WORKING_DIRECTORY
FILE_DIR="$WORKING_DIRECTORY/files"

if [ -d $FILE_DIR ];
then
        continue
else
        mkdir $FILE_DIR
fi

newFileName=`echo "Castlight_Contracts_full_"``date +"%Y%m%d%H%M%S"`.txt
hive -e "${QUERY}" | sed 's/[\t]/|/g' | sed 's/-//g'> $file
sed 's/++/-/g' $file | sed 's/-NULL//g' | sed 's/NULL-//g'  | sed 's/NULL//g' > $newFileName
