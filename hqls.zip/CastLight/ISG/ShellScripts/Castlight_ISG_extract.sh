#!/bin/bash
QUERY=`grep QUERY  $1 | cut -d ":" -f2`
WORKING_DIRECTORY=`grep WORKING_DIRECTORY  $1 | cut -d ":" -f2`
HADOOP_PATH=`grep HADOOP_PATH  $1 | cut -d ":" -f2`
file=Nasco.txt
ARC_DIR=`grep ARC_DIR $1 | awk -F":" '{print $2}'`
cd $WORKING_DIRECTORY
FILE_DIR="$WORKING_DIRECTORY/"

if [ -d $FILE_DIR ];
then
        continue
else
        mkdir $FILE_DIR
fi

for var in `ls $FILE_DIR/*Castlight*`
do
        oldFilename=`basename $var`
        arcFileName=`echo $oldFilename`_`date +"%m-%d-%Y-%H-%M-%S"`
        mv $var "$ARC_DIR/$arcFileName"
done

hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "${QUERY}" | sed 's/[\t]/|/g' > $file
sed 's/-NULL//g' $file | sed 's/NULL-//g' | sed 's/NULL//g' | sed 's/| /|/g' |sed 's/ |/|/g'|tr -d '"' | tr -d '[' | tr -d ']' | sed 's/,|/|/g' | sed 's/|,/|/g' | sed 's/N,N/N/g'| sed 's/Y,Y/Y/g'|sed 's/Y,N/Y/g' | sed 's/N,Y/Y/g'> Castlight_ISG_extract.txt
awk -F"|" '{print $70}' Castlight_ISG_extract.txt | sort | uniq | awk '{if ($1 != "") print $0}' >grp_name_temp.dat
ff="grp_name_temp.dat"
file=Castlight_ISG_extract.txt
#test=`hadoop fs -ls $HADOOP_PATH | sed '1d;s/  */ /g' | cut -d\  -f8`
prev_month=`date +'%m' -d 'last month'`
year=`date +'%Y'`
enrl_dat=$year"0101"
>isg_files.dat
while read -r line
do
        nm=`echo $line`
	#code=`echo $line | cut -b5-6`
        temp_file="$FILE_DIR/$nm.txt"
	header="H|"`date +"%Y%m%d"`"|F"
	echo $header > $temp_file
        awk -F"|" '{if ($70 == '\"$nm\"' && $90 == '\"Individual\"' ) print $0}' $file | cut -d'|' -f1-89  >> $temp_file
	
	sub_count=`grep -c '^SUB' $temp_file`
	dep_count=`grep -c '^DEP' $temp_file`
	total=`expr $sub_count + $dep_count`
	echo "T|"`printf "%020d" $total`"|"`printf "%020d" $sub_count`"|"`printf "%020d" $dep_count` >>$temp_file
#	grep ',' $temp_file | grep '@' | grep -i '.com' | awk -F"|" '{print $16}' | grep ',' >temp.dat
#	for i in `cat temp.dat`
#	do
#		b=`echo $i | awk -F"," '{print $2}'`
#	 	sed -i -e 's/'"$i"'/'"$b"'/g' $temp_file
#	done 
#	enrl_dat=`egrep 'SUB|DEP' $temp_file| awk -F"|" '{print $25}' | awk '{if ($1 != "") print $0}' | sort | head -1`
	
	if [ -f temp_file.dat ]
	then
	cat temp_file.dat > $temp_file
	fi
	lines=`wc -l $temp_file | awk -F" " '{print $1}'`
	if [ "$lines" -gt 2 ]
	then
        newFileName=`echo "Castlight_"$nm"_I_eligibility_full_"$enrl_dat"_88880808"`_`date +"%Y%m%d%H%M%S"`.txt

        mv $temp_file $FILE_DIR/$newFileName
  #      hadoop fs -copyFromLocal "$FILE_DIR/$newFileName" "$HADOOP_PATH/$newFileName"
	fi
	header="H|"`date +"%Y%m%d"`"|F"
        echo $header > $temp_file
        awk -F"|" '{if ($70 == '\"$nm\"' && $90 != '\"Individual\"' ) print $0}' $file | cut -d'|' -f1-89  >> $temp_file
        sub_count=`grep -c '^SUB' $temp_file`
        dep_count=`grep -c '^DEP' $temp_file`
        total=`expr $sub_count + $dep_count`
        echo "T|"`printf "%020d" $total`"|"`printf "%020d" $sub_count`"|"`printf "%020d" $dep_count` >>$temp_file
#	grep ',' $temp_file | grep '@' | grep -i '.com' | awk -F"|" '{print $16}' | grep ',' >temp.dat

#	for i in `cat temp.dat`
#	do
#		b=`echo $i | awk -F"," '{print $2}'`
#	 	sed -i -e 's/'"$i"'/'"$b"'/g' $temp_file
#	done 


	lines=`wc -l $temp_file | awk -F" " '{print $1}'`
	if [ "$lines" -gt 2 ]
	then

        newFileName=`echo "Castlight_"$nm"_S_eligibility_full_"$enrl_dat"_88880808"`_`date +"%Y%m%d%H%M%S"`.txt

        mv $temp_file $FILE_DIR/$newFileName
 #       hadoop fs -copyFromLocal "$FILE_DIR/$newFileName" "$HADOOP_PATH/$newFileName"
	fi

	if [ -f $temp_file ]
	then
		rm $temp_file
	fi
echo "C3|"$nm"|"$newFileName >> $FILE_DIR/isg_files.dat

done<$ff
chmod -R 777 $FILE_DIR/Castlight_*_S_eligibility_full_20180101_88880808_*

hadoop fs -rm /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_isg_statecodes/isg_files.dat
hadoop fs -put isg_files.dat /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_isg_statecodes/
hadoop fs -chmod -R 777 /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_isg_statecodes/*

