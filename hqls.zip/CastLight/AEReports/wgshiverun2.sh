#!/bin/bash
cd /ts/data/vs2/ehb/bds1/phi/no_gbd/r000/outbound/Extracts/CastLight/AEReport
file=ANTH_T_DTLS_`date +'%Y%m%d'`_W.TXT
echo "Script Running..!"
echo "HCID_ID|MBR_SQNC_NBR|MBR_CD|NEW_MBR_CD|SOR_CD|CNTRCT_CDE|INDICATOR|STATECODE|START_DATE|END_DATE" > $file
hive -e "select hcid_id,mbr_sqnc_nbr,mbr_cd,new_mbr_cd,sor_cd,cntrct_cde,indicatorvalue_list,start_date,end_date from ts_ehbbds1ph_nogbd_r000_in.aecontractindicator_extractdata_wgs;"  |  sed 's/[\t]/|/g' >> $file
chmod 777 $file
echo "Script Completed..!"
