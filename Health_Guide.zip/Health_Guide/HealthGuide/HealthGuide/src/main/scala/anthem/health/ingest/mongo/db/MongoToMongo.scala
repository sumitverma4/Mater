package anthem.health.ingest.mongo.db

import java.io.File
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

import scala.collection.JavaConversions._

import org.apache.commons.collections.CollectionUtils
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Level
import org.apache.log4j.LogManager
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.SparkSession
import org.bson.Document
import org.bson.conversions.Bson

import com.mongodb.spark._
import com.mongodb.spark.MongoSpark
import com.mongodb.spark.config._
import com.mongodb.spark.config.ReadConfig
import com.typesafe.config.Config
import com.typesafe.config.ConfigFactory
import anthem.health.utils.MongoBDSConfig
import com.mongodb.MongoClient
import com.mongodb.MongoClientURI



object MongoToMongo {

  def main(args: Array[String]): Unit = {

    val log = LogManager.getRootLogger
    log.setLevel(Level.WARN)
    val sparkConf = new SparkConf().setAppName("MongoToMongo").set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.ui.port", "3012").set("spark.rdd.compress", "true").set("spark.scheduler.mode", "FAIR")
      .set("spark.dynamicAllocation.enabled", "true").set("spark.shuffle.service.enabled", "true")

    sparkConf.registerKryoClasses(Array(Class.forName("anthem.health.ingest.mongo.db.MongoToMongo"), Class.forName("anthem.health.utils.Utils")))

    val dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val sparkContext = new SparkContext(sparkConf)
    val warehouseLocation = new File("spark-warehouse").getAbsolutePath
    val sqlContext = SparkSession.builder().appName("Extract").config("spark.sql.warehouse.dir", warehouseLocation).getOrCreate()
    val envType = args(0)

    val appConf = ConfigFactory.load()
    val URL = appConf.getString("bds.mongodb.mongodb_uri_" + envType.toLowerCase)
    val MONGO_DATABASE = appConf.getString("bds.mongodb.mongodb_" + envType.toLowerCase)
    val doc = MongoBDSConfig.getConfDetailKey(envType, "Customertype", args(1), appConf)

    val collectionName = doc.getString("collectionName")
   
    var df:DataFrame = null
    
    val uri = appConf.getString("bds.mongodb.mongodb_uri_" + args(0).toLowerCase()) + "." + doc.get("collectionName")
    val readConfig = ReadConfig(Map("uri" -> uri))
    

    val projeckblk = doc.getString("projeckblk") 
    
    val ouputrecords = MongoSpark.load(sparkContext, readConfig).withPipeline(Seq(Document.parse(projeckblk)))
   
    val dd =  ouputrecords.map(doc=>{ Document.parse("{ \"member\": "+doc.toJson()+" }") })
    val subcollectionName = doc.getString("subsetcollectionName")
    val wc = getWriteConfig(MONGO_DATABASE, subcollectionName , sparkConf, URL)
    MongoSpark.save(dd,wc)
     
    println(s"****** Saving of ************** $args(1) is done")
  }

  /**
   * Drops the collection if exists
   * @param dataFrame
   * @param writeConfig
   */
  
 import org.apache.spark.sql.Row
  def mkJson(r: Row): String =
    {
      val str = r.mkString("")
      //Document.parse(str)
      str
    }
 
def writeToMongoDB(dataFrame:DataFrame, writeConfig:WriteConfig, url:String, collectionName:String, appConf:Config, envType:String) = {
  
        val mongoClient = new MongoClient( new MongoClientURI(url+"?authMechanism=SCRAM-SHA-1"))
        val database = mongoClient.getDatabase(appConf.getString("bds.mongodb.mongodb_"+envType.toLowerCase))
        val collection = database.getCollection(collectionName) 
        
         if(collection.count() > 0){
          collection.drop()
          println(s"Collection Dropped ${collectionName}")
        }
        MongoSpark.save(dataFrame, writeConfig)
        println("Data has written to Mongo DB")
 }


  /**
   * @param dbase
   * @param collection
   * @param conf1
   * @return
   */
  def getWriteConfig(dbase: String, collection: String, conf1: SparkConf, url: String) = {
    import scala.collection.JavaConversions._
    import scala.collection.mutable._
    val opt: java.util.Map[String, String] = HashMap("writeConcern.w" -> "majority", "writeConcern.journal" -> "false", "maxBatchSize" -> "1000")
    WriteConfig.create(dbase, collection, url, 1, WriteConcernConfig.create(conf1).withOptions(opt).writeConcern)
  }

}