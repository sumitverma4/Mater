#!/bin/bash
DB_NAME=`grep DB_NAME $1 | cut -d ":" -f2`
INDICATOR_HQL_FILENAME=`grep INDICATOR_HQL_FILENAME $1 | cut -d ":" -f2`
INDICATOR_HQL_LOCATION=`grep INDICATOR_HQL_LOCATION $1 | cut -d ":" -f2`


beeline -u 'jdbc:hive2://dwbdprod1r1m.wellpoint.com:2181,dwbdprod1r2m.wellpoint.com:2181,dwbdprod1r3m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${INDICATOR_HQL_LOCATION}/${INDICATOR_HQL_FILENAME}"