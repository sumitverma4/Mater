#!/bin/bash
if [ -z "$1" ]
  then
    echo "Provide Configuration file as parameter"
    echo "e.g. -> sh ScriptExceutor.sh Script.cfg"
    exit 1
fi
DB_NAME=`grep DB_NAME  $1 | cut -d ":" -f2`
HQL_FILENAME=`grep HQL_FILENAME  $1 | cut -d ":" -f2`
HQL_LOCATION=`grep HQL_LOCATION  $1 | cut -d ":" -f2`
SCRIPT_LOCATION=`grep SCRIPT_LOCATION  $1 | cut -d ":" -f2`
SCRIPT_NAME=`grep SCRIPT_NAME  $1 | cut -d ":" -f2`
CONFIG_FILENAME=`grep CONFIG_FILENAME  $1 | cut -d ":" -f2`

beeline -u 'jdbc:hive2://dwbdprod1r1m.wellpoint.com:2181,dwbdprod1r2m.wellpoint.com:2181,dwbdprod1r3m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${HQL_LOCATION}/${HQL_FILENAME}"

sh $SCRIPT_LOCATION/$SCRIPT_NAME $SCRIPT_LOCATION/$CONFIG_FILENAME


