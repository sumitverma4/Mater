 if [[ $2 == "member" ]];
then
                 source_path=`grep source_path_member  $1 | cut -d "=" -f2`
                 hdfs_path=`grep hdfs_path_member  $1 | cut -d "=" -f2`
	         archive_path=`grep archive_path_member  $1 | cut -d "=" -f2`
                 echo $source_path
else
                source_path=`grep source_path_provider  $1 | cut -d "=" -f2`
		hdfs_path=`grep hdfs_path_provider  $1 | cut -d "=" -f2`
		archive_path=`grep archive_path_provider  $1 | cut -d "=" -f2`
                echo $source_path
fi
year=`date "+%Y%m%d"`
path=$source_path
hadoop_path=$hdfs_path/$year
arc_path=$archive_path/$year
echo $path

if [ ${#path[@]} -gt 0 ]; 
then 
     echo "files exist";
     hadoop fs -test -d $hadoop_path
	   if [ $? == 0 ]
	   then

                                hadoop fs -rm -r $hadoop_path
                                echo "hadooppath removed"
                                hadoop fs -mkdir $hadoop_path
                                hadoop fs -copyFromLocal $path  $hadoop_path
                else

                                    hadoop fs -mkdir $hadoop_path
                                    echo "directory created"
                                    hadoop fs -copyFromLocal $path  $hadoop_path
        fi
cd /home/srcehbbds1bthts/spark2
spark2-submit --conf spark.ui.enabled=true --conf spark.ui.port=10101 --conf spark.port.maxRetries=25 --master yarn --executor-cores 2 --executor-memory 10G --num-executors 25 --conf spark.driver.memory=20G --deploy-mode=cluster --conf spark.yarn.queue="ehub-xds_yarn" --conf spark.broadcast.compress=true  --conf spark.io.compression.codec=lz4 --jars  mongo-java-driver-3.4.3.jar,mongo-spark-connector_2.11-2.2.0.jar,spark-csv_2.10-1.4.0.jar,config-1.2.1.jar,commons-csv-1.5.jar,ojdbc6-11.2.0.3.jar,bds_header_utility-1.0-SNAPSHOT.jar --conf spark.driver.extraClassPath=/home/srcehbbds1bthts/spark2/*  --conf spark.executor.extraClassPath=/home/srcehbbds1bthts/spark2/* --class anthem.health.ingest.mongo.db.FileToMongoDB  HealthGuide-1.0-SNAPSHOT.jar health healthguide_member_data full $hadoop_path/*
else
echo "files not existing in the $path"

fi

if [ -d $arc_path ]
then
	cp $source_path $arc_path
        rm $source_path/*
else
	mkdir $arc_path
        cp $source_path $arc_path
        rm $source_path/*
fi
