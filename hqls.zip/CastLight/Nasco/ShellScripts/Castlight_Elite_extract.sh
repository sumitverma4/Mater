#!/bin/bash
QUERY=`grep QUERY  $1 | cut -d ":" -f2`
WORKING_DIRECTORY=`grep WORKING_DIRECTORY  $1 | cut -d ":" -f2`
HADOOP_PATH=`grep HADOOP_PATH  $1 | cut -d ":" -f2`
file=Nasco.txt
ARC_DIR=`grep ARC_DIR $1 | awk -F":" '{print $2}'`
cd $WORKING_DIRECTORY
FILE_DIR=$WORKING_DIRECTORY/

if [ -d $FILE_DIR ]
then
	continue
else
	mkdir $FILE_DIR
fi


prev_month=`date +'%m' -d 'last month'`
year=`date +'%Y'`
enrl_dat="20180101"

>nasco_elite_file.dat
hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "${QUERY}" | sed 's/[\t]/|/g' > $file
sed 's/NULL//g' $file > Castlight_extract.txt 
awk -F"|" '{print $41}' Castlight_extract.txt | sort | uniq | awk '{if ($1 != "") print $0}'>grp_name_temp.dat

for var in `ls $FILE_DIR/*Castlight_*_N_eligibility_full_*`
do
        oldFilename=`basename $var`
        arcFileName=`echo $oldFilename`_`date +"%m-%d-%Y-%H-%M-%S"`
        mv $var "$ARC_DIR/$arcFileName"
done

file=Castlight_extract.txt
while read -r line
do
	code=`echo $line | awk -F"|" '{print $1}'`
	temp_file=$FILE_DIR/$code".txt"
	header="H|"`date +"%Y%m%d"`"|F"
	echo $code
	echo $header > $temp_file
	cat $file |awk -F"|" '{if ($41 == '\"$code\"') print $0}'  | cut -d'|' -f1-89 | tr -d '"' | tr -d '[' | tr -d ']' | sed 's/,|/|/g' | sed 's/|,/|/g' | sed 's/N,N/N/g'| sed 's/Y,Y/Y/g'|sed 's/Y,N/Y/g' | sed 's/N,Y/Y/g' >> $temp_file
	sub_count=`grep -c '^SUB' $temp_file` 
	dep_count=`grep -c '^DEP' $temp_file`
	total=`expr $sub_count + $dep_count`
	echo "T|"`printf "%020d" $total`"|"`printf "%020d" $sub_count`"|"`printf "%020d" $dep_count` >>$temp_file
	name=`echo $nm | tr -d ','| tr -d '.' | tr -d '/'| tr -s '-' | sed 's\ \-\g'`
	newFileName=`echo "Castlight_"$code"_N_eligibility_full_"$enrl_dat"_88880808"`_`date +"%Y%m%d%H%M%S"`.txt
	mv $temp_file $FILE_DIR/$newFileName 
echo "Elite & Essential|"$code"|"$newFileName >> $FILE_DIR/nasco_elite_file.dat

done<grp_name_temp.dat
chmod -R 777 $FILE_DIR/*

hadoop fs -rm /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_nasco/nasco_elite_file.dat
hadoop fs -put $FILE_DIR/nasco_elite_file.dat /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_nasco/
hadoop fs -chmod -R /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_nasco/*
