#!/bin/bash
QUERY=`grep QUERY  $1 | cut -d ":" -f2`
WORKING_DIRECTORY=`grep WORKING_DIRECTORY  $1 | cut -d ":" -f2`
HADOOP_PATH=`grep HADOOP_PATH  $1 | cut -d ":" -f2`
file=Nasco.txt
ARC_DIR=`grep ARC_DIR $1 | awk -F":" '{print $2}'`
FILE_DIR="$WORKING_DIRECTORY/"
FILE_TYPE=`grep FILE_TYPE $1 | awk -F":" '{print $2}'`

if [ -d $FILE_DIR ];
then
        continue
else
        mkdir $FILE_DIR
fi


for var in `ls $FILE_DIR/*Castlight_*_W_eligibility_full_*`
do
        oldFilename=`basename $var`
        arcFileName=`echo $oldFilename`_`date +"%m-%d-%Y-%H-%M-%S"`
        mv $var "$ARC_DIR/$arcFileName"
done


cd $WORKING_DIRECTORY
prev_month=`date +'%m' -d 'last month'`
year=`date +'%Y'`
enrl_dat=$year"0101"
>wgs_r1r4_file.dat
hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "${QUERY}" | sed 's/[\t]/|/g' > $file
sed 's/++/-/g' $file | sed 's/-NULL//g' | sed 's/NULL-//g'  | sed 's/NULL//g' > Castlight_WGS_extract.txt
awk -F"|" '{print $41}' Castlight_WGS_extract.txt | sort | uniq >grp_name_temp.dat

ff="grp_name_temp.dat"
file=Castlight_WGS_extract.txt
while read -r line
do
        code=`echo $line | awk -F"|" '{print $1}'`
        nm=`echo $line | awk -F"|" '{print $2}'`
        temp_file=$FILE_DIR/$code".txt"
        header="H|"`date +"%Y%m%d"`"|F"
        echo $header > $temp_file
	awk -F"|" '{if ($41 == '\"$code\"') print $0}' $file | cut -d'|' -f1-89 | tr -d '"' | tr -d '[' | tr -d ']' | sed 's/,|/|/g' | sed 's/|,/|/g' | sed 's/N,N/N/g'| sed 's/Y,Y/Y/g'|sed 's/Y,N/Y/g' | sed 's/N,Y/Y/g' >> $temp_file
        #grep $code $file |  cut -d'|' -f1-80 >> $temp_file
        sub_count=`grep -c '^SUB' $temp_file`
        dep_count=`grep -c '^DEP' $temp_file`
        total=`expr $sub_count + $dep_count`
        echo "T|"`printf "%020d" $total`"|"`printf "%020d" $sub_count`"|"`printf "%020d" $dep_count` >>$temp_file
#        enrl_dat=`egrep 'SUB|DEP' $temp_file| awk -F"|" '{print $28}' | sort | head -1`

        name=`echo $nm | tr -d ','| tr -d '.' | tr -d '/' | sed 's\ \-\g'`
        newFileName=`echo "Castlight_"$code"_W_eligibility_full_"$enrl_dat"_88880808"`_`date +"%Y%m%d%H%M%S"`.txt
        mv $temp_file $FILE_DIR/$newFileName
	filelist=`echo "$FILE_TYPE|$code|$newFileName"`
	echo $filelst >> wgs_files_`date +"%Y%m%d"`.txt
 #       hadoop fs -copyFromLocal "$FILE_DIR/$newFileName" $HADOOP_PATH/$newFileName
echo "R1-R4 Files|"$code"|"$newFileName >> $FILE_DIR/wgs_r1r4_file.dat


done<$ff
chmod -R 777 $FILE_DIR/*

hadoop fs -rm /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_wgs/wgs_r1r4_file.dat
hadoop fs -put wgs_r1r4_file.dat /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_wgs/
hadoop fs -chmod -R 777 /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_wgs/*

