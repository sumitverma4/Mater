#!/bin/bash
echo "Script Running..!"
echo "HCID_ID|MBR_SQNC_NBR|MBR_CD|NEW_MBR_CD|SOR_CD|CNTRCT_CDE|INDICATOR|STATECODE|START_DATE|END_DATE" > /home/af56152/SE-88442_txtfiles/ANTH_T_DTLS_20160125_N.TXT
hive -e "select hcid_id,mbr_sqnc_nbr,mbr_cd,new_mbr_cd,sor_cd,cntrct_cde,indicatorvalue_list,start_date,end_date from ts_ehbbds1ph_nogbd_r000_in.aecontractindicator_extractdata_nasco;"  |  sed 's/[\t]/|/g' >> /home/af56152/SE-88442_txtfiles/ANTH_T_DTLS_20160125_N.TXT 
echo "Script Completed..!"