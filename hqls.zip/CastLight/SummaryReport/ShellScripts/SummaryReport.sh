#!/bin/bash
if [ -z "$1" ]
  then
    echo "Provide Configuration file as parameter"
    echo "e.g. -> sh ScriptExecutor.sh ScriptConfig.cfg"
    exit 1
fi
DB_NAME=`grep DB_NAME  $1 | cut -d ":" -f2`
HQL_FILENAME=`grep HQL_FILENAME  $1 | cut -d ":" -f2`
HQL_LOCATION=`grep HQL_LOCATION  $1 | cut -d ":" -f2`
NASCO_HQL_FILENAME=`grep NASCO_HQL_FILENAME $1 | cut -d ":" -f2`
WGS_HQL_FILENAME=`grep WGS_HQL_FILENAME $1 | cut -d ":" -f2`
ISG_HQL_FILENAME=`grep ISG_HQL_FILENAME $1 | cut -d ":" -f2`
STATE_HQL_FILENAME=`grep STATE_HQL_FILENAME $1 | cut -d ":" -f2`
SCRIPT_LOCATION=`grep SCRIPT_LOCATION $1 | cut -d ":" -f2`
NASCO_SCRIPT_NAME=`grep NASCO_SCRIPT_NAME $1 | cut -d ":" -f2`
NASCO_CONFIG_NAME=`grep NASCO_CONFIG_NAME $1 | cut -d ":" -f2`
WGS_SCRIPT_NAME=`grep WGS_SCRIPT_NAME $1 | cut -d ":" -f2`
WGS_CONFIG_NAME=`grep WGS_CONFIG_NAME $1 | cut -d ":" -f2`
ISG_SCRIPT_NAME=`grep ISG_SCRIPT_NAME $1 | cut -d ":" -f2`
ISG_CONFIG_NAME=`grep ISG_CONFIG_NAME $1 | cut -d ":" -f2`
STATE_SCRIPT_NAME=`grep STATE_SCRIPT_NAME $1 | cut -d ":" -f2`
STATE_CONFIG_NAME=`grep STATE_CONFIG_NAME $1 | cut -d ":" -f2`

#beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${HQL_LOCATION}/${NASCO_HQL_FILENAME}"

#beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${HQL_LOCATION}/${WGS_HQL_FILENAME}"

#beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${HQL_LOCATION}/${ISG_HQL_FILENAME}"

#beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -hiveconf CURRENT_DB="${DB_NAME}" -f "${HQL_LOCATION}/${STATE_HQL_FILENAME}"

cd $SCRIPT_LOCATION

sh $SCRIPT_LOCATION/$NASCO_SCRIPT_NAME $SCRIPT_LOCATION/$NASCO_CONFIG_NAME
sh $SCRIPT_LOCATION/$WGS_SCRIPT_NAME $SCRIPT_LOCATION/$WGS_CONFIG_NAME
sh $SCRIPT_LOCATION/$ISG_SCRIPT_NAME $SCRIPT_LOCATION/$ISG_CONFIG_NAME
sh $SCRIPT_LOCATION/$STATE_SCRIPT_NAME $SCRIPT_LOCATION/$STATE_CONFIG_NAME

sh SendEmail.sh
