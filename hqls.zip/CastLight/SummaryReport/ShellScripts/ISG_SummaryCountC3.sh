#!/bin/bash
#*******************************************************************************#
# Title        :- ISG_SummaryCountC3.sh	  			                            #
#-------------------------------------------------------------------------------#
# Description  :- Script will extract data from Hive table for ISG              #
#		          Counts and dump it in a .CSV file      						#	
#-------------------------------------------------------------------------------#
# Created By   :-  Krishna Adari	                                            #
# Date         :-  11/12/2017                                                   #
#*******************************************************************************#
#
#=======================================================#
#   Below are the Global variables used in the script   #
#=======================================================#

if [ $# -eq 0 ]
  then
    echo "Error:Please Pass The Script File Along With Config File As Below"
    echo "sh ISG_SummaryCountC3.sh ISG_SummaryCountC3.cfg"
    exit
fi

QUERY=`grep QUERY  $1 | awk -F":" '{print $2}'`
WORKING_DIRECTORY=`grep WORKING_DIRECTORY  $1 | awk -F":" '{print $2}'`
EXTRACT_PATH=`grep EXTRACT_PATH  $1 | awk -F":" '{print $2}'`
file=`grep FILE_NAME $1 | awk -F":" '{print $2}'`
HEADER=`grep HEADER $1 | awk -F":" '{print $2}'`
ARC_DIR=`grep ARC_DIR $1 | awk -F":" '{print $2}'`
cd $WORKING_DIRECTORY
hive -e "${QUERY}" | sed 's/[\t]/,/g' > $file
newFileName=`echo $file`_`date +"%m%d%Y"`.csv
echo $HEADER >$newFileName
sed 's/NULL//g' $file | awk 'BEGIN{ FS=" *, "; OFS="," } {$1=$1; print $0}'|sed -e 's/^\|$/"/g' -e 's/,/",="/g' >> $newFileName
#arcFileName=`echo $newFileName`_`date +"%m-%d-%Y-%H-%M-%S"`
for var in `ls $EXTRACT_PATH/*`
do
        oldFilename=`basename $var`
        arcFileName=`echo $oldFilename`_`date +"%m-%d-%Y-%H-%M-%S"`
	    echo "here"
#        mv $var "$ARC_DIR/$arcFileName"
done
mv "$newFileName" "$EXTRACT_PATH/$newFileName"
##############END################
