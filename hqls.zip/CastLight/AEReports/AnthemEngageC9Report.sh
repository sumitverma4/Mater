#!/bin/bash
echo "Script Running..!"
file=C9_Report_`date +'%Y%m%d'`.csv
cd /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/AEReport/
echo "Group_ID,Group_name,State_Code,Count"> $file
hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "select src_group_id,grp_nm,underwriting_state_code,Count(*) from dv_ehbbds1ph_nogbd_r000_in.wgs_extract_final_f t1 where t1.Medical_Contract_Code in (select distinct trim(t2.column5) from dv_ehbbds1ph_nogbd_r000_in.WGS_GROUPS_K2356 t2) group by src_group_id,grp_nm,underwriting_state_code;"  |  sed 's/[\t]/#/g' | tr -d ',' | sed 's/#/,/g' | sed -e 's/$/"/g' -e 's/,/",="/g' | sed -e 's/^/="/g' >> $file
chmod 777 $file
mv /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/C9_Report* /dv/data/vs2/ehb/bds1/phi/no_gbd/r000/outbound/Extracts/CastLight/AEReport/
mv C9_Report* /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/
echo "Script Completed..!"
