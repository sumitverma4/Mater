#!/bin/bash
echo "Script Running..!"
cd /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/AEReport
beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' --hiveconf mapred.job.queue.name=bdf_yarn -f AnthemEliteReport.hql

file=Anthem_Elite_Report_`date +'%Y%m%d'`.csv
echo "Group_ID,Group_name,Source_System,Contract_Code,CastLight_Indicator,Indicator_Start_date,Indicator_End_date" > $file
hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "select distinct * from dv_ehbbds1ph_nogbd_r000_in.Anthem_Engage_ENE_Report;"  |  sed 's/[\t]/#/g' | tr -d ',' | sed 's/#/,/g' | sed -e 's/$/"/g' -e 's/,/",="/g' | sed -e 's/^/="/g' >> $file
chmod 777 $file
mv /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/Anthem_Elite_Report_*.csv /dv/data/vs2/ehb/bds1/phi/no_gbd/r000/outbound/Extracts/CastLight/AEReport/
mv Anthem_Elite_Report_*.csv /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/
echo "Script Completed..!"
