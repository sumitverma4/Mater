
beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' --hiveconf mapred.job.queue.name=bdf_yarn -f AEReport.hql

sh wgshiverun2.sh
sh nascorun2.sh

