#!/bin/bash
echo "Script Running..!"
file=Anthem_Group_ANA_Report_`date +'%Y%m%d'`.csv
cd /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/AEReport/
beeline -u 'jdbc:hive2://dwbdtest1r2m3.wellpoint.com:2181,dwbdtest1r1m.wellpoint.com:2181,dwbdtest1r2m.wellpoint.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2' -f AnthemGroupANAReport.hql
echo "Group_ID,Sub_Group_ID,Group_name,Contract_Code,CastLight_Indicator,National_Indicator" > $file
hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "select distinct Group_ID,Sub_Group_ID,regexp_replace(Group_name,',',''),Contract_code,regexp_replace(Indicator,',',' '),National_Indicator from dv_ehbbds1ph_nogbd_r000_in.Anthem_Engage_Group_Report_WGS union all select distinct Group_ID,Sub_Group_ID,regexp_replace(Group_name,',',''),Contract_code,regexp_replace(Indicator,',',' '),National_Indicator from dv_ehbbds1ph_nogbd_r000_in.Anthem_Engage_Group_Report_Nasco" |  sed 's/[\t]/#/g' | sed 's/#/,/g' | sed -e 's/^\|$/"/g' -e 's/,/",="/g' | sed -e 's/^/=/g' | sed -e 's/%/,/g' >> $file
chmod 777 $file
mv /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/Anthem_Group_ANA_Report_*.csv /dv/data/vs2/ehb/bds1/phi/no_gbd/r000/outbound/Extracts/CastLight/AEReport/
mv Anthem_Group_ANA_Report_*.csv /dv/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/
echo "Script Completed..!"
