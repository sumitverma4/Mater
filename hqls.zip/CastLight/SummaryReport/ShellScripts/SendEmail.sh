

##############################################################################
# DEFINING THE LOG PARAMETER FOR THE SCRIPT
###############################################################################

LOG_DIR=/ts/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/LOG/
LOG=$LOG_DIR/Summary_Report_`date +%Y%m%d`.log
ZIPFILE='Summary_Report_'`date +%Y%m%d`.zip
ISGFILE=`ls -lrt ISG_SummaryCounts_Report_*.csv | tail -1 | awk -F" " '{print $9}'`
WGSFILE=`ls -lrt WGS_SummaryCounts_Report_*.csv | tail -1 | awk -F" " '{print $9}'`
NASCOFILE=`ls -lrt Nasco_SummaryCounts_Report_*.csv | tail -1 | awk -F" " '{print $9}'`
SUMMARY_REPORT=Eligibilty_File_Summary_Report_`date +%Y%m%d`.csv
STATEFILE=`ls -lrt SummaryCounts_StateBased_C9C8C7_Report*.csv | tail -1 | awk -F" " '{print $9}'`
HEADER="CATEGORY,GROUP_NAME,GROUP_ID,FILENAME,COUNTSFROMEXTRACTS,EXPECTEDCOUNT,VARIANCE,VARIANCE_PERCENTAGE,EMAIL_PRESENT,EMAIL_PRESENT_PERCENTAGE"

echo $HEADER > $SUMMARY_REPORT

grep -v "CATEGORY" $ISGFILE >> $SUMMARY_REPORT
grep -v "CATEGORY" $NASCOFILE >> $SUMMARY_REPORT
grep -v "CATEGORY" $WGSFILE >> $SUMMARY_REPORT
grep -v "CATEGORY" $STATEFILE >> $SUMMARY_REPORT

echo "---- Starting the script at $(date +'%d/%m/%y %H:%M:%S') -----" >> $LOG
cd /ts/app/vs2/ehb/bds1/phi/no_gbd/r000/bin/Extracts/SummaryReport/ShellScripts/

###############################################################################
# Starting of Script
###############################################################################

Start_date=`date '+%C%y%m%d' -d "$end_date-7 days"`
End_date=`date '+%C%y%m%d' -d "$end_date-$1 days"`

echo "---- Total records extracted $total -----" >> $LOG

###############################################################################
# Sending Mail with zipped attachement
###############################################################################


head -1 $NASCOFILE > Files_With_Variance.csv

for file in $ISGFILE $NASCOFILE $WGSFILE $STATEFILE
do
awk -F'",="' '{ if ($8 > 3) print $0}' $file >> Files_With_Variance.csv
done

#head -1 $NASCOFILE > Files_With_Variance.csv
var_diff=`wc -l Files_With_Variance.csv| awk -F" " '{print $1}'`

if [ $var_diff -gt 1 ]
then
	rm $ZIPFILE
	zip $ZIPFILE $SUMMARY_REPORT C9_Member_Count.csv Files_With_Variance.csv Anthem_Elite_Report_20180418.csv
	#zip $ZIPFILE $NASCOFILE 
	echo -e "Hi All,\n\nPFA Summary Report for CastLight Eligibility files.\n\n Please feel free to reply on this mail in case of any queries.\n\nRegards,\nBDS Team " |  mailx -s "CastLight Summary Reports" -a $ZIPFILE -S "from=BDS" sumit.verma2@anthem.com,murthy.snnr@anthem.com,Prashant.Sukhe@anthem.com
	#echo -e "Hi All,\n\nPFA Summary Report for CastLight Eligibility files.\n\n Please feel free to reply on this mail in case of any queries.\n\nRegards,\nBDS Team " |  mailx -s "CastLight Summary Reports" -a $ZIPFILE -S "from=BDS" sumit.verma2@anthem.com
else
rm $ZIPFILE	
#zip $ZIPFILE $ISGFILE $NASCOFILE $WGSFILE $STATEFILE C9_Member_Count.csv
zip $ZIPFILE $SUMMARY_REPORT C9_Member_Count.csv Anthem_Elite_Report_20180418.csv
#zip $ZIPFILE $NASCOFILE
	
	echo -e "Hi All,\n\nBelow files have been FTPed.\n\n\n•	Contract File for WGS ,NASCO and ISG combined\n•	Category 9 state based files\n•	Category 3 files\n•	Elite and Essentials files\n•	R1-R4 files\n•	Category 8 files\n\n\nPFA Summary Report for CastLight Eligibility files.\n\nPlease feel free to reply on this mail in case of any queries.\n\nRegards,\nBDS Team " |  mailx -s "CastLight Summary Reports" -a $ZIPFILE -S "from=BDS" sumit.verma2@anthem.com,murthy.snnr@anthem.com,Prashant.Sukhe@anthem.com
	#echo -e "Hi All,\n\nAll files have been FTPed for this week.\n\n\nPFA Summary Report for CastLight Eligibility full files.\n\nPlease feel free to reply on this mail in case of any queries.\n\nRegards,\nEHUB XDS Team " | mailx -s "CastLight Summary Reports" -a $ZIPFILE -S "from=dl-Cognizant_EMPI-CIRS-CHUB_Support@anthem.com" ksitts@castlighthealth.com,Prashant.Sukhe@anthem.com,danielle.custalow@anthem.com,Monique.Jackson-King@anthem.com,Eric.Underwood@anthem.com,vijendra.runwal@anthem.com,jlau@castlighthealth.com,proney@castlighthealth.com,ahunt@castlighthealth.com,Navaneethakrishnan.Narayanasamy2@anthem.com,anirudh.jain@anthem.com,Sarada.Kaligotla@anthem.com,Sabrina.Zagrodnick@anthem.com,mshah@castlighthealth.com,Ross.Merritt@anthem.com,timothy.christian@anthem.com,greg.gugger@anthem.com,ajarrell@ChooseHMC.com,mgoldfischer@care-anthem.com,stephanie.fedrick@anthem.com,kishore.mayalavarapu@anthem.com,murthy.snnr@anthem.com,Barry.Goodman@anthem.com,Geo.Khunju@anthem.com
fi


echo "---- Script Ended. Mail sent at $(date +'%d/%m/%y %H:%M:%S') -----" >> $LOG

###############################################################################
# Ending of script
###############################################################################


