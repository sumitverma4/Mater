package anthem.health.ingest.mongo.db

import java.util.Date

import org.apache.log4j.Level
import org.apache.log4j.LogManager
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.bson.Document

import com.mongodb.spark.MongoSpark
import com.mongodb.spark.config.WriteConcernConfig
import com.mongodb.spark.config.WriteConfig
import com.typesafe.config.Config
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import com.mongodb.MongoClient
import com.mongodb.MongoClientURI
import com.mongodb.client.model.IndexOptions
import anthem.health.utils.MongoBDSConfig
import org.apache.spark.sql.SparkSession
import java.io.File
import com.mongodb.spark.config.ReadConfig

import scala.collection.JavaConversions._

import org.apache.commons.collections.CollectionUtils
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Level
import org.apache.log4j.LogManager
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.SparkSession
import org.bson.Document
import org.bson.conversions.Bson

import com.typesafe.config.Config
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame


object FileToMongoDB {

  def main(args: Array[String]): Unit = {

    val log = LogManager.getRootLogger
    log.setLevel(Level.WARN)
    val sparkConf = new SparkConf().setAppName("FileToMongoDB").set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.ui.port", "3012").set("spark.rdd.compress", "true").set("spark.scheduler.mode", "FAIR")
      .set("spark.dynamicAllocation.enabled", "true").set("spark.shuffle.service.enabled", "true")

    sparkConf.registerKryoClasses(Array(Class.forName("anthem.health.ingest.mongo.db.FileToMongoDB"), Class.forName("anthem.health.utils.Utils")))

    val dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val sparkContext = new SparkContext(sparkConf)
    val warehouseLocation = new File("spark-warehouse").getAbsolutePath
    val sqlContext = SparkSession.builder().appName("Spark Hive Example").config("spark.sql.warehouse.dir", warehouseLocation).enableHiveSupport().getOrCreate()
    val envType = args(0)

    val appConf = ConfigFactory.load()
    val URL = appConf.getString("bds.mongodb.mongodb_uri_" + envType.toLowerCase)
    val MONGO_DATABASE = appConf.getString("bds.mongodb.mongodb_" + envType.toLowerCase)
    val doc = MongoBDSConfig.getConfDetailKey(envType, "Customertype", args(1), appConf)

    val collectionName = doc.getString("collectionName")
    val distnictField = doc.getString("distnictField")
    
    val filepath = doc.getString("fileLocation") 
    val fileformat = doc.getString("fileformat")
    var df:DataFrame = null
    
    if(fileformat.equalsIgnoreCase("json")){
       df = sqlContext.read.json(filepath)
       println("json file read "+df.count())
    }else if (fileformat.equalsIgnoreCase("parquet")){
      df = sqlContext.read.parquet(filepath)
    }else{
      df = sqlContext.read.text(filepath)
    }
    
    if (args(2).equalsIgnoreCase("full")) {
       writeToMongoDB(df, getWriteConfig(MONGO_DATABASE, collectionName, sparkConf, URL), URL, collectionName, appConf, envType)
    }else{
       val uri = URL+"."+collectionName
       val readConfig = ReadConfig(Map("uri" -> uri))
       
       val mongoData = MongoSpark.load(sparkContext, readConfig).toDF()
       val mongoDataWithoutID = mongoData.drop("_id")
       val columnHeadersName = df.columns.mkString(",")
       val fixedColumns = fixColumns(mongoDataWithoutID, doc, sqlContext, "health", columnHeadersName)
       df.printSchema()
       println("--------------------------- mongo ")
       fixedColumns.printSchema()
       val deltafileFlag = doc.getString("deltafile")
       var deltaRecords:DataFrame = null
       println("flag -- "+deltafileFlag)
       if(deltafileFlag.equalsIgnoreCase("Y")){
         deltaRecords = df
       }else
       {
        deltaRecords  = df.except(fixedColumns)
       }
       
       deltaRecords.createOrReplaceTempView("delta")
       mongoData.createOrReplaceTempView("mongoData")
       
       val deltaQuery= doc.getString("deltaQuery").replace("<DELTA_DATA>","delta").replace("<MONGO_DATA>", "mongoData").replace("<UFIELD>", distnictField)
       val updatedDF = sqlContext.sql(deltaQuery)
       writeToMongoDB(updatedDF, getWriteConfig(MONGO_DATABASE, collectionName, sparkConf, URL), URL, collectionName, appConf, envType)
       
    }  
    println(s"****** Saving of ************** $args(1) is done")
  }

  /**
   * Drops the collection if exists
   * @param dataFrame
   * @param writeConfig
   */
def writeToMongoDB(dataFrame:DataFrame, writeConfig:WriteConfig, url:String, collectionName:String, appConf:Config, envType:String) = {
  
        val mongoClient = new MongoClient( new MongoClientURI(url+"?authMechanism=SCRAM-SHA-1"))
        val database = mongoClient.getDatabase(appConf.getString("bds.mongodb.mongodb_"+envType.toLowerCase))
        val collection = database.getCollection(collectionName) 
      /*  
         if(collection.count() > 0){
          collection.drop()
          println(s"Collection Dropped ${collectionName}")
        }*/
        MongoSpark.save(dataFrame, writeConfig)
        println("Data has written to Mongo DB")
 }


  /**
   * @param dbase
   * @param collection
   * @param conf1
   * @return
   */
  def getWriteConfig(dbase: String, collection: String, conf1: SparkConf, url: String) = {
    import scala.collection.JavaConversions._
    import scala.collection.mutable._
    val opt: java.util.Map[String, String] = HashMap("writeConcern.w" -> "majority", "writeConcern.journal" -> "false", "maxBatchSize" -> "1000")
    WriteConfig.create(dbase, collection, url, 1, WriteConcernConfig.create(conf1).withOptions(opt).writeConcern)
  }

  
    def fixColumns(dataFrame: DataFrame, doc: Document, sqlContext: SparkSession, conType: String, columnHeadersName: String) = {
    val listColumns = dataFrame.columns.toList
    val totalColumns = columnHeadersName.split(",").toList //appConf.getStringList("bds.colsDisplay")//colHeader.split(",").toList
    var data: DataFrame = null

    if (dataFrame.take(1).length > 0) {
     
        val diffCols = CollectionUtils.subtract(totalColumns, listColumns)
        var sqlOutput: DataFrame = null
        if (diffCols.size() > 0) {
          dataFrame.createOrReplaceTempView(conType)
          var colNames = " "
          for (col <- diffCols) {
            colNames += "'' as " + col.toString() + ","
          }

          val query = "Select *,<COLS> from " + conType
          val qquery = query.replace("<COLS>", StringUtils.chop(colNames))
          println("Query	" + qquery)
          val stt = System.currentTimeMillis()
          sqlOutput = sqlContext.sql(s"$qquery")
        }
        if (sqlOutput == null) {
          sqlOutput = dataFrame
        }
        data = sqlOutput.na.fill("", listColumns)
       // println(" distinct " + doc.getString("doDistinctDF"))


     /* println("before withColumn");
      val dateFmt = doc.getString("dateFormatinCSV")

      import org.apache.spark.sql.functions._
      if (doc.getString("dateFormatFields") != null) {
        val dateField1 = doc.getString("dateFormatFields").split(",")
        for (dtField <- dateField1) {
          val field = dtField.split("~")(0)
          println("field:" + field)
          val dtFormat = dtField.split("~")(1)
          data = data.withColumn(field, when(col(field).isNull, "").otherwise(date_format(col(field), dtFormat)))
          println("data:" + data)
        }
      }
      if (doc.getString("dateField") != null) {
        val dateField = doc.getString("dateField").split(",")
        for (dtField <- dateField) {
          data = data.withColumn(dtField, when(col(dtField).isNull, "").otherwise(date_format(col(dtField), dateFmt)))
        }
      }*/
      var finalDataFrame = data.select(totalColumns.head, totalColumns.tail: _*)
      /*if (doc.getString("doDistinctDF") != null) {
        println("Doing distinct ")
        finalDataFrame = finalDataFrame.distinct()
      }*/
      finalDataFrame
    } else {
      data
    }

  }
    
      def filterDF(data: DataFrame, document: Document, actDoc: Document, sqlContext: SparkSession) = {
    println("Enterred filterDF  ")
    var outDF: DataFrame = null
    var sqlDF: DataFrame = null
    var columns: Array[String] = null

    val templateName = document.getString("templateName")
    data.createOrReplaceTempView(templateName)
    if (document.getString("colHeader") != null) {
      val colHeaderName = document.getString("colHeader")
      println("colHeaderName " + colHeaderName)
      columns = actDoc.getString(colHeaderName).split(",")
      outDF = data.select(columns.head, columns.tail: _*)
    } else {
      outDF = data
    }
    if (document.getString("filterKey") != null && document.getString("filterValue") != null) {
      outDF = outDF.filter(data.col(document.getString("filterKey")).like(document.getString("filterValue")))
    }
    if (document.getString("sqlQuery") != null) {
      val sqlQueryDF = actDoc.getString(document.getString("sqlQuery")).replace("<SQL_TABLENAME>", templateName)
      val sqlDF = sqlContext.sql(sqlQueryDF)

      if (document.getString("doUnionDistinct") != null) {
        outDF = outDF.union(sqlDF).distinct()
      }
      outDF = outDF.select(columns.head, columns.tail: _*)

    }

    println("Exiting filterDF ")
    outDF
  }
}