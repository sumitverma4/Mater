#!/bin/bash
NASCO_QUERY=`grep NASCO_QUERY  $1 | cut -d ":" -f2`
WORKING_DIRECTORY=`grep WORKING_DIRECTORY  $1 | cut -d ":" -f2`
EXTRACT_PATH=`grep EXTRACT_PATH  $1 | cut -d ":" -f2`
file=Nasco_11_k.txt
ARC_DIR=`grep ARC_DIR $1 | awk -F":" '{print $2}'`
cd $WORKING_DIRECTORY
WGS_QUERY=`grep WGS_QUERY $1 | cut -d ":" -f2`

if [ -d $EXTRACT_PATH ]
then
	continue
else
	mkdir $EXTRACT_PATH
fi


prev_month=`date +'%m' -d 'last month'`
year=`date +'%Y'`
enrl_dat="20170801"

for var in `ls $EXTRACT_PATH/*_W_eligibility_full*`
do
        oldFilename=`basename $var`
        arcFileName=`echo $oldFilename`_`date +"%m-%d-%Y-%H-%M-%S"`
        mv $var "$ARC_DIR/$arcFileName"
done
>$EXTRACT_PATH/c11_file.dat
#hive -e "${NASCO_QUERY}" | sed 's/[\t]/|/g' > $file
hive --hiveconf mapred.job.queue.name=ehub-xds_yarn -e "${WGS_QUERY}" | sed 's/[\t]/|/g' > $file
sed 's/NULL//g' $file | tr -d '"' | tr -d '[' | tr -d ']' | sed 's/,|/|/g' | sed 's/|,/|/g' | sed 's/N,N/N/g'| sed 's/Y,Y/Y/g'|sed 's/Y,N/Y/g' | sed 's/N,Y/Y/g' > Castlight_extract_11_k.txt 
awk -F"|" '{print $41}' Castlight_extract_11_k.txt | sort | uniq | awk '{if ($1 != "") print $0}'>state_11_grp_name_temp.dat

file=Castlight_extract_11_k.txt
while read -r line
do
	code=`echo $line`
	temp_file=$EXTRACT_PATH/$code"C9.txt"
	header="H|"`date +"%Y%m%d"`"|F"
	echo $code
	echo $header > $temp_file
	cat $file |awk -F"|" '{if ($41 == '\"$code\"') print $0}'  | cut -d'|' -f1-89 >> $temp_file
	sub_count=`grep -c '^SUB' $temp_file` 
	dep_count=`grep -c '^DEP' $temp_file`
	total=`expr $sub_count + $dep_count`
	echo "T|"`printf "%020d" $total`"|"`printf "%020d" $sub_count`"|"`printf "%020d" $dep_count` >>$temp_file
	name=`echo $nm | tr -d ','| tr -d '.' | tr -d '/'| tr -s '-' | sed 's\ \-\g'`
	newFileName=`echo "Castlight_"$code"_W_eligibility_full_"$enrl_dat"_88880808"`_`date +"%Y%m%d%H%M%S"`.txt
	mv $temp_file $EXTRACT_PATH/$newFileName 
echo "C9|"$code"|"$newFileName >> $EXTRACT_PATH/c11_file.dat

done<state_11_grp_name_temp.dat
chmod -R 777 $EXTRACT_PATH/*

hadoop fs -rm /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_isg_statecodes/c11_file.dat
hadoop fs -put $EXTRACT_PATH/c11_file.dat /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_isg_statecodes/
hadoop fs -chmod -R 777 /ts/hdfsdata/vs2/ehb/bds1/phi/no_gbd/r000/inbound/filenames_isg_statecodes/*

rm c11_file.dat state_11_grp_name_temp.dat Castlight_extract_11_k.txt Nasco_11_k.txt 
